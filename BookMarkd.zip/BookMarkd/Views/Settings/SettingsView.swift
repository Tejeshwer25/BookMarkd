//
//  SettingsView.swift
//  BookMarkd
//
//  Created by Tejeshwer Singh on 08/01/26.
//

import SwiftUI

enum SettingsOptionList: String, CaseIterable {
    case genrePreferences = "Genre preferences"
    case appearance = "Appearance"
    case about = "About"
}

struct SettingsView: View {
    @EnvironmentObject private var router: Router
    
    var body: some View {
        List(SettingsOptionList.allCases, id: \.self, rowContent: { setting in
            Button {
                navigateToScreen(setting)
            } label: {
                HStack {
                    Text(setting.rawValue)
                    Spacer()
                    Image(systemName: "chevron.right")
                }
            }
            .buttonStyle(.plain)
        })
        .padding(.top)
        .navigationTitle("Settings")
    }
    
    func navigateToScreen(_ screenName: SettingsOptionList) {
        switch screenName {
        case .genrePreferences:
            withAnimation {
                self.router.pushScreen(.genrePreferenceScreen)
            }
        default: break
        }
    }
}

#Preview {
    var router = Router()
    
    NavigationStackContainer(router: router) {
        SettingsView()
    }
}
